<?php include("include/header.php"); ?>
    <!-- main body will go here, body tags are already distributed to header and footer-->
<p>you are logging in</p>    

<?php include("include/footer.php"); ?>