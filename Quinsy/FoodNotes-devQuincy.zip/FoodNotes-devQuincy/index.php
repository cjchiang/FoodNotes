<?php include("include/header.php"); ?>
    <!-- main body will go here, body tags are already distributed to header and footer-->
<div style="background-color: lightgreen;">
    <p>I am home</p>
    <p>I am home</p>
    <p>I am home</p>
    <p>I am home</p>
    <p>I am home</p>
    <p>I am home</p>
    <p>I am home</p>
</div>

<?php include("include/footer.php"); ?>