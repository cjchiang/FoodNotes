<div class="container-fluid bottomRow">
    <hr/>
    <div class="row">
        <p>bottom stuff</p>
    </div>
</div>
    </body>
</html>