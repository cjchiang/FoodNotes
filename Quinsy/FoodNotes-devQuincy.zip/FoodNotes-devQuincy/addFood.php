<?php include("include/header.php"); ?>
    <!-- main body will go here, body tags are already distributed to header and footer-->
    <div class="container-fluid ourContent">
        <div id="canvasSelect col-xs-12">
            <canvas id="canvasSelection" width="500px" height="500px" style="border:1px solid black"></canvas>
        </div>
    </div>-->

<?php include("include/footer.php"); ?>