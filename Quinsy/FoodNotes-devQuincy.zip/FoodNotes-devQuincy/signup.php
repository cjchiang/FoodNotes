<?php include("include/header.php"); ?>
    <!-- main body will go here, body tags are already distributed to header and footer-->
<p>you are signing up</p>

<?php include("include/footer.php"); ?>